//Aidan Mast OOP Assignment 4
package assignment4;

public class Record {
	
	private int number;
	private String value;
	
	// no argument constructor
	public Record() {
		number = 0;
		value = "none";
	}
	
	// constructor sets record using inputs
	public Record(int number, String value) {
		this.number = number;
		this.value = value;
	}
	
	// gets number
	public int getNumber() {
		return number;
	}
	
	// gets value
	public String getValue() {
		return value;
	}
	
	// sets number
	public void setNumber(int number) {
		this.number = number;		
	}
	
	// sets value
	public void setValue(String value) {
		this.value = value;
	}
	
	// returns formatted string of record
	public String toString() {
		return ("" + number + ":" + value);
	}
}

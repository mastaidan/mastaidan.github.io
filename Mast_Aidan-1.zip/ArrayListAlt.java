//Aidan Mast OOP Assignment 4
package assignment4;
import java.util.ArrayList;

public class ArrayListAlt {
	
	private ArrayList<Record> myList;
	
	// no argument constructor creates empty array of records
	public ArrayListAlt() {
		myList = new ArrayList<Record>();
	}
	
	// returns size of array
	public int size() {
		return myList.size();
	}
	
	// finds record in array given number with binary search
	private int find(int number) {
		
		int target = number;
		int l = 0, r = myList.size() - 1;
		
		// binary search
        while (l <= r) {
            int m = l + (r - l) / 2;

            if (myList.get(m).getNumber() == target)
                return m;

            if (myList.get(m).getNumber() < target)
                l = m + 1;

            else
                r = m - 1;
        }
        return -1;
	}
	
	// adds record to array and sorts it ascending by record number
	public void add(Record r) {
		int index = 0;
		
		// traverses index to find correct spot
		while(true) {
			
			// if index is the end of the array, then add record
			if ((myList.size() <= index)){
				myList.add(r);
				break;
			}
			// if number at index is greater than the record number, then insert record
			if ((myList.get(index).getNumber() > r.getNumber())) {
				myList.add(index, r);
				break;
			}
			// if records are the same, then update old value with new value
			if (myList.get(index).getNumber() == r.getNumber()) {
				myList.get(index).setValue(r.getValue());
				break;
			}
			// if number at index is less than the record number, then increment
			if (myList.get(index).getNumber() < r.getNumber()) {
				index++;
			}
		}
	}
	
	// finds record with given number and returns value
	public String get(int number) {
		if (find(number) != -1) {
			return myList.get(find(number)).getValue();
		}
		return "null";
	}
	
	// remove record given number
	public boolean remove(int number) throws Exception{
		if (find(number) != -1){
			myList.remove(find(number));
			return true;
		}
		throw new Exception();
	}
	
	// returns string of array with formating
	@Override public String toString() {
		if(myList.size() != 0) {
			// starts string
			String str = "[";
			// adds records to string except last
			for (int i = 0; myList.size() -1> i; i++){
				str = str + myList.get(i).toString() + ", ";
			}
			// adds formatted last record
			str = str + myList.get(size() - 1).toString() + "]";
			return str;
		}
		return "";
	}
}
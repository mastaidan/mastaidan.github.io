//Aidan Mast OOP Assignment 4
package assignment4;

public class MyHashTable {
	
	private ArrayListAlt hashArr[];
	private int size;
	
	// no argument constructor defaults to size 11
	public MyHashTable(){
		
		// assigns hash to array of alt arrays
		hashArr = new ArrayListAlt[11];
		size = 11;
		
		// fills hash with alt arrays
		for( int i = 0; i < size; i++) {
			hashArr[i] = new ArrayListAlt();
		}
	}
	// constructor defaults for size n
	public MyHashTable(int n){
		
		// assigns hash to array of alt arrays
		hashArr = new ArrayListAlt[n];
		
		// fills hash with alt arrays
		for( int i = 0; i < n; i++) {
			hashArr[i] = new ArrayListAlt();
		}
		size = n;
	}
	
	// gets size
	public int getSize() {
		return size;
	}
	
	// takes number and outputs position in hash
	private int hashFunc(int position) {
		return position % size;	
	}
	
	// adds record to corresponding array in hash based on hashFunc
	public void add(Record a) {
		int spot = hashFunc(a.getNumber());
		hashArr[spot].add(a);
	}
	
	// removes record from hash given its record number
	public void remove(int number) {
		int spot = hashFunc(number);
		try {
			hashArr[spot].remove(number);
		} catch (Exception e){
			System.out.println("No such element");
		}
	}
	
	// get record value from hash given record number
	public String get(int number) {
		int spot = hashFunc(number);
		return hashArr[spot].get(number);
	}
	
	// prints hash in format displaying hash
	@Override public String toString() {
		for (int i = 0; i < size; i++) {
			System.out.println(i + ":" + hashArr[i].toString());
		}
		return "";
	}
}
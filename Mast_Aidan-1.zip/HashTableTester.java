//Aidan Mast OOP Assignment 4
package assignment4;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;


public class HashTableTester{
	public static void main(String[] args) {
		
		// scan command line for file name
		Scanner scan = new Scanner(System.in);
		String file = scan.nextLine();
		
		// opens file 
		String strline = "";
		File myObj = new File(file);
		Scanner myReader = null;
		try {
			myReader = new Scanner(myObj);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		
		// reads first line of file for size of hash table
		strline = myReader.nextLine();
		MyHashTable hashArr = new MyHashTable(Integer.parseInt(strline));
		
		// init while loop variables for data parsing
		String func = "";
		String info = "";
		int number;
		int colon;

		// while loop to parse data and insert data into hash table
		while (myReader.hasNext()) {
			
			// reads next line, tokens it, then separates into function and info 
			strline = myReader.nextLine();
			StringTokenizer tokens = new StringTokenizer(strline);
			func = tokens.nextToken();
			info = tokens.nextToken();
			
			// if func is add, add info hash table
			if (func.equals("add")) {
				colon = info.indexOf(":");
				number = Integer.parseInt(info.substring(0, colon));
				info = info.substring((colon + 1));
				Record r = new Record(number, info);
				hashArr.add(r);
			}
			
			// if func is remove, remove data from hash table
			if (func.equals("remove")) {
				number = Integer.parseInt(info);
				hashArr.remove(number);
			}
		}
		
		// close file and print hash table
		myReader.close();
		hashArr.toString();
	}
}